from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from app.data import BASE_CONFIG
from app.models import *
from app.optimizer import evaluate
from app.queueing import screen_configuration
from app.scenario_parser import parse_question

app = FastAPI(title="PulseTwin API", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
_scenario_store: dict[str, dict] = {}
_decision_history: list[DecisionRecord] = []


def _status(value: float) -> str:
    return "strained" if value >= 90 else "watch" if value >= 78 else "healthy"


@app.get("/api/status", response_model=WardStatus)
def get_status():
    fast = screen_configuration(BASE_CONFIG.arrivals_per_hour, BASE_CONFIG.doctors, BASE_CONFIG.minutes_per_patient_doctor, BASE_CONFIG.severity_mix["critical"])
    utilization = fast["doctor_utilization_pct"]
    beds_available = max(0, BASE_CONFIG.beds - round(BASE_CONFIG.beds * 0.72))
    return WardStatus(
        timestamp=datetime.now(timezone.utc).isoformat(), arrivals_per_hour=BASE_CONFIG.arrivals_per_hour,
        patients_in_system=round(BASE_CONFIG.arrivals_per_hour * 1.7), doctors=BASE_CONFIG.doctors, nurses=BASE_CONFIG.nurses,
        beds=BASE_CONFIG.beds, beds_available=beds_available, avg_wait_minutes=fast["avg_wait_minutes"],
        critical_wait_minutes=fast["critical_wait_minutes"], serious_wait_minutes=round(fast["avg_wait_minutes"] * 0.92, 1),
        staff_utilization_pct=utilization, throughput_per_hour=round(BASE_CONFIG.arrivals_per_hour * 0.84, 1),
        queue_length=round(BASE_CONFIG.arrivals_per_hour * 0.38), acuity_mix=BASE_CONFIG.severity_mix,
        resources=[
            ResourceStatus(name="Doctors", used=round(BASE_CONFIG.doctors * utilization / 100), total=BASE_CONFIG.doctors, utilization_pct=utilization, status=_status(utilization)),
            ResourceStatus(name="Nurses", used=round(BASE_CONFIG.nurses * min(100, utilization * .88) / 100), total=BASE_CONFIG.nurses, utilization_pct=round(utilization * .88, 1), status=_status(utilization * .88)),
            ResourceStatus(name="Beds", used=BASE_CONFIG.beds - beds_available, total=BASE_CONFIG.beds, utilization_pct=72, status="watch"),
            ResourceStatus(name="CT", used=1, total=1, utilization_pct=91, status="strained"),
            ResourceStatus(name="Lab", used=1, total=2, utilization_pct=64, status="healthy"),
        ],
        trend=[TrendPoint(label=label, arrivals=arrivals, wait_minutes=wait, utilization_pct=util) for label, arrivals, wait, util in [("06:00", 18, 21, 66), ("09:00", 24, 28, 78), ("12:00", 27, 34, 86), ("15:00", 25, 31, 82), ("18:00", 29, 39, 93), ("Now", 25, fast["avg_wait_minutes"], utilization)]],
        alerts=["CT capacity is the current bottleneck", "Critical-patient wait is above the 15 min target", "Night shift demand forecast is +30%"],
    )


@app.post("/api/scenario/parse", response_model=ParsedScenario)
def post_parse(body: ScenarioParseRequest):
    if not body.question.strip():
        raise HTTPException(status_code=400, detail="question must not be empty")
    return parse_question(body.question)


@app.post("/api/scenario/evaluate", response_model=EvaluationResult)
def post_evaluate(body: ScenarioEvaluateRequest):
    baseline, candidates, recommendation, sim_cache = evaluate(body.scenario, BASE_CONFIG)
    _scenario_store[body.scenario.id] = {"scenario": body.scenario, "sims": sim_cache, "recommendation": recommendation}
    return EvaluationResult(scenario=body.scenario, baseline=baseline, candidates=candidates, recommendation=recommendation, pipeline=["Question parsed", "12 configurations screened", "4 candidates simulated", "Severity-aware score calculated", "Recommendation generated"], computed_at=datetime.now(timezone.utc).isoformat())


@app.get("/api/ward/state", response_model=WardTwinState)
def get_ward_state(scenario_id: str = Query(..., alias="scenarioId"), candidate_id: str = Query(..., alias="candidateId")):
    entry = _scenario_store.get(scenario_id)
    if not entry or candidate_id not in entry["sims"]:
        raise HTTPException(status_code=404, detail="Unknown scenario or candidate. Evaluate a scenario first.")
    sim = entry["sims"][candidate_id]
    event_log = ["10:01 · Patient P101 arrived", "10:04 · P101 entered triage", "10:11 · P101 assigned to doctor", "10:23 · P101 moved to testing", "10:47 · P101 entered treatment", "11:18 · P101 discharged"]
    return WardTwinState(scenario_id=scenario_id, applied_label=candidate_id, simulated_minutes=360, stage_counts=sim["stage_counts"], patients=sim["patients"], event_log=event_log, resource_utilization=sim["resource_utilization"])


@app.get("/api/decisions", response_model=list[DecisionRecord])
def get_decisions():
    return list(reversed(_decision_history))


@app.post("/api/decisions", response_model=DecisionRecord)
def create_decision(body: DecisionCreateRequest):
    record = DecisionRecord(id=f"decision-{len(_decision_history) + 1}", scenario_id=body.scenario_id, question=body.question, recommendation=body.recommendation, impact=body.impact, created_at=datetime.now(timezone.utc).isoformat())
    _decision_history.append(record)
    return record
