import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ command }) => {
  const repositoryName = process.env.GITHUB_REPOSITORY?.split("/")[1];
  const base = process.env.VITE_BASE_PATH ?? (command === "build" && repositoryName ? `/${repositoryName}/` : "/");

  return {
    base,
    plugins: [react()],
    server: {
      port: 5173,
    },
  };
});
