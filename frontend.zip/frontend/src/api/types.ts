export type Severity = "critical" | "serious" | "mild";

export interface ResourceStatus { name: string; used: number; total: number; utilizationPct: number; status: "healthy" | "watch" | "strained"; }
export interface TrendPoint { label: string; arrivals: number; waitMinutes: number; utilizationPct: number; }
export interface WardStatus {
  timestamp: string; arrivalsPerHour: number; patientsInSystem: number; doctors: number; nurses: number; beds: number; bedsAvailable: number;
  avgWaitMinutes: number; criticalWaitMinutes: number; seriousWaitMinutes: number; staffUtilizationPct: number; throughputPerHour: number; queueLength: number;
  acuityMix: Record<string, number>; resources: ResourceStatus[]; trend: TrendPoint[]; alerts: string[];
}
export interface ParsedScenario {
  id: string;
  rawQuestion: string;
  arrivalSurgePct: number;
  timePeriod: string;
  objective: string;
  arrivalsPerHour?: number;
  doctors?: number;
  nurses?: number;
  beds?: number;
  triageNurses?: number;
  ctCapacity?: number;
  labCapacity?: number;
  extraDoctors?: number;
  extraNurses?: number;
  extraBeds?: number;
}
export interface CandidateResult {
  id: string; label: string; doctorsAdded: number; nursesAdded: number; bedsAdded: number; avgWaitMinutes: number; criticalWaitMinutes: number; seriousWaitMinutes: number;
  throughputPerHour: number; doctorUtilizationPct: number; bedUtilizationPct: number; score: number; fastScreenScore: number; isRecommended: boolean; tradeoff: string;
}
export interface EvaluationResult {
  scenario: ParsedScenario; baseline: CandidateResult; candidates: CandidateResult[];
  recommendation: { summary: string; reasoning: string; whyNow: string; impact: Record<string, number>; guardrails: string[] };
  pipeline: string[]; computedAt: string;
}
export interface DecisionRecord { id: string; scenarioId: string; question: string; recommendation: string; impact: Record<string, number>; createdAt: string; }
export type PipelineStage = "ARRIVED" | "TRIAGE" | "WAITING_FOR_DOCTOR" | "DOCTOR" | "TESTING" | "TREATMENT" | "WAITING_FOR_BED" | "BED" | "DISCHARGED";
export interface WardPatient { id: string; severity: Severity; stage: PipelineStage; waitMinutes: number; }
export interface WardTwinState { scenarioId: string; appliedLabel: string; simulatedMinutes: number; stageCounts: Record<PipelineStage, number>; patients: WardPatient[]; eventLog: string[]; resourceUtilization: Record<string, number>; }
